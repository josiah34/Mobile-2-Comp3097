//
//  ViewController.swift
//  lab4
//
//  Created by mac on 2023-02-19.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

